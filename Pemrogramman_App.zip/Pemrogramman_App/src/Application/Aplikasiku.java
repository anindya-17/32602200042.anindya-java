
package Application;

public class Aplikasiku {

    private static class string {

        public string() {
        }
    }
 
// interface registrasi
interface Registration {
    void register();
}

class Person {
    private String name;
    private String address;

    //constructor
    public Person(String name, String address) {
        this.name = name;
        this.address = address;
    }

    // Getter and Setter for name
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Getter and Setter for address
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}

// inheritance dr kelas register
class User extends Register {
    private String email;
    private String password;

    public User(String name, String address, String email, String password) {

        this.email = email;
        this.password = password;
    }

    // Getter and Setter for email
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Getter and Setter for password
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void register() {
        System.out.println("User registered successfully!");
    }
}


class Register extends javax.swing.JFrame {
    private User user;

    public Register() {
        initComponents();
        user = new User("", "", "", "");
    }

   
    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

        private void initComponents() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

}
}

/* Encapsulation terdapat pada variabel private 

*/