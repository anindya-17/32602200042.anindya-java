
package Application;


public class main {
    
    public static void main(String[] args) {
         // Polymorphism
       Register reg = new Register();
        reg.setVisible(true);

        
    }
}
